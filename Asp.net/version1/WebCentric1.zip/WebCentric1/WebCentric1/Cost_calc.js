﻿
var app = angular.module('myApp', []);
app.controller('costCtrl', function ($scope) {
    var noOfPassengers = document.getElementById('passengers').value;

    var v1 = document.getElementById('droplist');
    var strUser = parseInt(v1.options[v1.selectedIndex].value);

    var val = 0;

    if (document.getElementById('RadioButton1').checked == true) {
        val = 1;
    } else if (document.getElementById('RadioButton2').checked == true) {
        val = 2;
    }
    var c = parseInt(val);
    var  a = parseInt(noOfPassengers) * 250;

    var  d = a * c * strUser;
    $scope.cost= d;

    });

    